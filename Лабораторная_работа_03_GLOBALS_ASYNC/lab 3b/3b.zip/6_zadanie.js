// Функция для вычисления квадрата
function calculateSquare(number) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(number * number);
      }, 2000);
    });
  }
  
  // Функция для вычисления куба
  function calculateCube(number) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(number * number * number);
      }, 1500);
    });
  }
  
  // Функция для вычисления четвертой степени
  function calculateFourthPower(number) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(Math.pow(number, 4));
      }, 2000);
    });
  }
  
  // Пример использования Promise.race() для вычисления математических функций
  const inputNumber = 2;
  
  Promise.race([
    calculateSquare(inputNumber),
    calculateCube(inputNumber),
    calculateFourthPower(inputNumber),
  ])
    .then((result) => {
      console.log('First result:', result);
    })
    .catch((error) => {
      console.error('Error:', error.message);
    });
  
  // Пример использования Promise.any() для получения первого разрешившегося Promise
  Promise.any([
    calculateSquare(inputNumber),
    calculateCube(inputNumber),
    calculateFourthPower(inputNumber),
  ])
    .then((result) => {
      console.log('First resolved result:', result);
    })
    .catch((error) => {
      console.error('All promises were rejected:', error.message);
    });
  