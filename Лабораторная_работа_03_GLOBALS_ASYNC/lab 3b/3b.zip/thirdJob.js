// Функция, принимающая параметр data и возвращающая Promise
function thirdJob(data) {
    return new Promise((resolve, reject) => {
      if (typeof data !== 'number') {
        reject(new Error('Ошибка: data не является числом'));
      } else if (data % 2 === 1) {
        setTimeout(() => {
          resolve('odd');
        }, 1000);
      } else if (data % 2 === 0) {
        setTimeout(() => {
          reject(new Error('even'));
        }, 2000);
      }
    });
  }
  
  // Обработка Promise с использованием обработчиков
  thirdJob(5)
    .then((result) => {
      console.log('С использованием обработчиков Promise:', result);
    })
    .catch((error) => {
      console.error('Ошибка при обработке Promise:', error.message);
    });
  
  // Обработка Promise с использованием async/await и try/catch
  async function handleThirdJobWithAsyncAwait() {
    try {
      const result = await thirdJob('awd');
      console.log('С использованием async/await и try/catch:', result);
    } catch (error) {
      console.error('Ошибка при обработке async/await:', error.message);
    }
  }
  
  // Вызов функции для обработки Promise с использованием async/await и try/catch
  handleThirdJobWithAsyncAwait();
  