// Функция для вычисления квадрата
function calculateSquare(number) {
    return new Promise((resolve, reject) => {
      if (typeof number !== 'number') {
        reject(new Error('Invalid input. Please provide a number.'));
      } else {
        resolve(number * number);
      }
    });
  }
  
  // Функция для вычисления куба
  function calculateCube(number) {
    return new Promise((resolve, reject) => {
      if (typeof number !== 'number') {
        reject(new Error('Invalid input. Please provide a number.'));
      } else {
        resolve(number * number * number);
      }
    });
  }
  
  // Функция для вычисления четвертой степени
  function calculateFourthPower(number) {
    return new Promise((resolve, reject) => {
      if (typeof number !== 'number') {
        reject(new Error('Invalid input. Please provide a number.'));
      } else {
        resolve(Math.pow(number, 4));
      }
    });
  }
  
  // Пример использования Promise.all() для вычисления квадрата, куба и четвертой степени
  const inputNumber = 'a';
  
  Promise.all([
    calculateSquare(inputNumber),
    calculateCube(inputNumber),
    calculateFourthPower(inputNumber),
  ])
    .then((results) => {
      console.log('Square:', results[0]);
      console.log('Cube:', results[1]);
      console.log('Fourth Power:', results[2]);
    })
    .catch((error) => {
      console.error('Error:', error.message);
    });
  