const { v4: uuidv4 } = require('uuid');

// Функция для проверки валидности карты
function validateCard(cardNumber) {
  console.log('Card Number:', cardNumber);
  // Рандомная проверка валидности карты
  return Math.random() < 0.5; 
}

// Функция создания заказа
function createOrder(cardNumber) {
  return new Promise((resolve, reject) => {
    // Проверка валидности карты
    if (validateCard(cardNumber)) {
      // Генерация номера заказа
      const orderId = uuidv4();

      // Разрешение Promise со значением orderId спустя 5 секунд
      setTimeout(() => {
        resolve(orderId);
      }, 5000);
    } else {
      // Отклонение Promise с ошибкой
      reject(new Error('Card is not valid'));
    }
  });
}

// Функция для обработки оплаты
function proceedToPayment(orderId) {
  console.log('Order ID:', orderId);
  return new Promise((resolve, reject) => {
    // Рандомное разрешение или отклонение Promise
    const paymentSuccess = Math.random() < 0.5; 

    if (paymentSuccess) {
      resolve('Payment successful');
    } else {
      reject(new Error('Payment failed'));
    }
  });
}

// Вызов createOrder и proceedToPayment с использованием обработчиков Promise
createOrder('1234567890123456')
  .then((orderId) => {
    return proceedToPayment(orderId);
  })
  .then((paymentResult) => {
    console.log(paymentResult);
  })
  .catch((error) => {
    console.error(  error.message);
  });

// Вызов createOrder и proceedToPayment с использованием async/await и try/catch
async function handleOrderAndPayment() {
  try {
    const orderId = await createOrder('1234567890123456');
    const paymentResult = await proceedToPayment(orderId);
    console.log(paymentResult);
  } catch (error) {
    console.error(error.message);
  }
}

// Вызов функции для обработки с использованием async/await и try/catch
handleOrderAndPayment();
